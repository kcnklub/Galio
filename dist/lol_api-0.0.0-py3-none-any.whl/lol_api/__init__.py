from lol_api.LoLApi import LolApi

__all__ = ['parameters', 'LolApi']
